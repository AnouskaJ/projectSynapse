// src/components/AgentStream.jsx
"use client"

import React, { useEffect, useRef, useState } from "react"
import { buildRunUrl, API_BASE } from "../utils/api"

// ⬇️ Firebase Messaging (frontend)
import { getMessaging, getToken, onMessage, isSupported } from "firebase/messaging"
import { app } from "../lib/firebase" // must export initialized firebase app

/* ------------ Small UI helpers ------------ */
const Pill = ({ children, tone = "neutral" }) => {
  const cls =
    tone === "ok"
      ? "bg-emerald-900/40 text-emerald-300 border-emerald-800"
      : tone === "warn"
        ? "bg-amber-900/40 text-amber-300 border-amber-800"
        : tone === "err"
          ? "bg-rose-900/40 text-rose-300 border-rose-800"
          : "bg-slate-800/60 text-slate-300 border-slate-700"
  return <span className={`pill border ${cls}`}>{children}</span>
}

const K = ({ children }) => <span className="text-gray-400">{children}</span>

/* Pretty printer without raw JSON blocks */
function PrettyObject({ data }) {
  if (data == null) return <div className="text-gray-400">—</div>
  if (typeof data !== "object") return <div className="text-gray-200 break-words">{String(data)}</div>

  if (Array.isArray(data)) {
    if (data.length === 0) return <div className="text-gray-400">[]</div>
    return (
      <ul className="space-y-1">
        {data.map((item, i) => (
          <li key={i} className="rounded-lg bg-black/20 border border-[var(--grab-edge)] p-2">
            <PrettyObject data={item} />
          </li>
        ))}
      </ul>
    )
  }

  const entries = Object.entries(data)
  if (entries.length === 0) return <div className="text-gray-400">{`{}`}</div>

  return (
    <dl className="grid sm:grid-cols-2 gap-x-4 gap-y-2">
      {entries.map(([k, v]) => (
        <div key={k} className="min-w-0">
          <dt className="text-xs uppercase tracking-wider text-gray-400">{k}</dt>
          <dd className="text-gray-200">
            <PrettyObject data={v} />
          </dd>
        </div>
      ))}
    </dl>
  )
}

/* Step card with subtle animation */
function StepItem({ step, index, active = false, complete = false }) {
  const [open, setOpen] = React.useState(true)
  const ok = !!step.success
  return (
    <div
      id={`step-${index}`}
      className="relative pl-6"
      style={{ animation: `fadeInUp 400ms ease ${index * 80}ms both` }}
      aria-current={active ? "step" : undefined}
    >
      {/* Timeline dot and line */}
      <div className="absolute left-0 top-2">
        <div
          className={`w-3 h-3 rounded-full ${ok ? "bg-emerald-400" : "bg-rose-400"} ring-4 ring-[var(--grab-bg)] ${
            active ? "timeline-dot-active" : ""
          }`}
        />
      </div>
      {index !== 0 && (
        <div
          className={`absolute left-1 top-[-24px] bottom-6 w-[2px] ${complete ? "conn-complete" : "conn-upcoming"}`}
        />
      )}

      <div className={`card p-4 ${active ? "step-active" : ""}`}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Pill>Step {step.idx}</Pill>
            <div className="font-semibold text-white">{step.intent || "—"}</div>
          </div>
          <div className="flex items-center gap-2">
            <Pill tone={ok ? "ok" : "err"}>{ok ? "passed" : "failed"}</Pill>
            <button
              type="button"
              className="btn btn-ghost"
              aria-expanded={open}
              aria-label={open ? "Collapse step details" : "Expand step details"}
              onClick={() => setOpen((v) => !v)}
              title={open ? "Collapse" : "Expand"}
            >
              {open ? "Hide" : "Show"}
            </button>
          </div>
        </div>

        {/* meta row */}
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <div className="text-xs text-gray-400 mb-1">Tool</div>
            <div className="font-medium text-[var(--grab-green)]">{step.tool || "none"}</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 mb-1">Assertion</div>
            <div className="font-medium text-gray-200 break-words">{step.assertion || "—"}</div>
          </div>
          <div>
            <div className="text-xs text-gray-400 mb-1">Timestamp</div>
            <div className="font-medium text-gray-200">{step.ts}</div>
          </div>
        </div>

        {open && (
          <div className="mt-4 grid md:grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-gray-400 mb-1">Params</div>
              <PrettyObject data={step.params} />
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-1">Observation</div>
              <PrettyObject data={step.observation} />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/* Sliding toggle between GUI and CLI */
function ViewToggle({ mode, setMode }) {
  const isGUI = mode === "gui"
  return (
    <div className="w-[220px] rounded-full border border-[var(--grab-edge)] bg-black/20 p-1 relative select-none">
      <div
        className={`absolute top-1 bottom-1 w-[108px] rounded-full transition-transform ${
          isGUI ? "translate-x-1" : "translate-x-[109px]"
        }`}
        style={{ background: "linear-gradient(90deg,#0c1511,#14231c)" }}
      />
      <div className="relative z-10 grid grid-cols-2 text-xs font-medium">
        <button
          type="button"
          aria-pressed={isGUI}
          onClick={() => setMode("gui")}
          className={`py-1.5 ${isGUI ? "text-white" : "text-gray-400"}`}
        >
          GUI Chain
        </button>
        <button
          type="button"
          aria-pressed={!isGUI}
          onClick={() => setMode("cli")}
          className={`py-1.5 ${!isGUI ? "text-white" : "text-gray-400"}`}
        >
          CLI Chain
        </button>
      </div>
    </div>
  )
}

/* ---- keyframes for fadeInUp ---- */
const style = document.createElement("style")
style.innerHTML = `
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(12px) }
  to   { opacity: 1; transform: translateY(0) }
}`
if (!document.getElementById("fadeInUpKeyframes")) {
  style.id = "fadeInUpKeyframes"
  document.head.appendChild(style)
}

/* ------------ Main component ------------ */
export default function AgentStream({ scenarioText }) {
  const [events, setEvents] = useState([])
  const [rawLines, setRawLines] = useState([])
  const [status, setStatus] = useState("idle") // idle | streaming | done | error
  const [error, setError] = useState("")
  const [mode, setMode] = useState("gui") // gui | cli
  const [activeIndex, setActiveIndex] = useState(-1)
  const [isPlaying, setIsPlaying] = useState(false)
  const [followLive, setFollowLive] = useState(true) // when streaming, jump to latest
  const playSpeed = 900 // ms per step when playing
  const esRef = useRef(null)

  // FCM state
  const [fcmSupported, setFcmSupported] = useState(false)
  const [fcmToken, setFcmToken] = useState("")
  const [notifPermission, setNotifPermission] = useState(Notification?.permission ?? "default")

  // Safe preview URL in the UI (no token)
  const previewUrl = scenarioText
    ? `${API_BASE}/api/agent/run?${new URLSearchParams({ scenario: scenarioText }).toString()}`
    : ""

  // Register SW + wire foreground messages
  useEffect(() => {
    let cleanup = () => {}
    ;(async () => {
      try {
        const supported = await isSupported()
        setFcmSupported(supported)
        if (!supported) return

        // Service worker MUST exist at /firebase-messaging-sw.js (in public/)
        const reg = await navigator.serviceWorker.register("/firebase-messaging-sw.js")
        const messaging = getMessaging(app)

        // Foreground messages (optional)
        const off = onMessage(messaging, (payload) => {
          // You can surface UI toast/snackbar here
          console.log("[FCM] foreground payload:", payload)
        })
        cleanup = () => off()
      } catch (e) {
        console.error("FCM bootstrap failed:", e)
      }
    })()
    return () => cleanup()
  }, [])

  async function enableNotifications() {
    try {
      const permission = await Notification.requestPermission()
      setNotifPermission(permission)
      if (permission !== "granted") {
        setError("Notifications blocked. Please allow notifications to receive pushes.")
        return
      }
      const messaging = getMessaging(app)
      // ⬇️ Your VAPID public key goes here
      const token = await getToken(messaging, {
        vapidKey:
          "BKCnh74gURGvjrBN-dB7HaxMPqrSfrNHe7bm1MNbDqxPN9IZsVkVhmNL8fhc_zkgoTlx8ywKg9T5NExxT_0WjHw"
      })
      if (!token) {
        setError("Failed to obtain an FCM token.")
        return
      }
      setFcmToken(token)
      console.log("[FCM] token:", token)
      setError("")
    } catch (e) {
      console.error("Enable notifications failed:", e)
      setError(e?.message || "Failed to enable notifications")
    }
  }

  useEffect(() => {
    // cleanup on unmount
    return () => {
      if (esRef.current) esRef.current.close()
    }
  }, [])

  const start = async () => {
    if (!scenarioText) return

    // Close any previous stream
    if (esRef.current) {
      esRef.current.close()
      esRef.current = null
    }

    setActiveIndex(-1)
    setIsPlaying(false)
    setFollowLive(true)

    setEvents([])
    setRawLines([])
    setError("")
    setStatus("streaming")

    try {
      // Build URL and include the REAL device token
      const urlWithToken = await buildRunUrl({
        scenario: scenarioText,
        passenger_token: fcmToken || undefined // only include if present
      })

      const es = new EventSource(urlWithToken)
      esRef.current = es

      es.onmessage = (evt) => {
        const line = evt.data
        setRawLines((prev) => [...prev, line])
        if (!line) return
        if (line === "[DONE]") {
          setStatus("done")
          es.close()
          esRef.current = null
          setFollowLive(false)
          return
        }
        try {
          const payload = JSON.parse(line)
          setEvents((prev) => [...prev, payload])
        } catch {
          // ignore non-JSON pings
        }
      }

      es.onerror = () => {
        setStatus("error")
        setError("Stream error. Ensure backend is running, CORS allowed, and token is valid.")
        es.close()
        esRef.current = null
      }
    } catch (e) {
      setStatus("error")
      setError(e.message || "Failed to start stream")
    }
  }

  const stop = () => {
    if (esRef.current) {
      esRef.current.close()
      esRef.current = null
    }
    setStatus("done")
    setIsPlaying(false)
    setFollowLive(false)
  }

  // Partition events
  const classification = events.find((e) => e.type === "classification")?.data
  const steps = events.filter((e) => e.type === "step").map((e) => e.data)
  const summary = events.find((e) => e.type === "summary")?.data

  useEffect(() => {
    if (followLive && steps.length > 0) {
      setActiveIndex(steps.length - 1)
    }
  }, [steps.length, followLive])

  useEffect(() => {
    if (!isPlaying) return
    const id = setInterval(() => {
      setActiveIndex((i) => {
        const next = Math.min((i ?? -1) + 1, steps.length - 1)
        if (next === i || next < 0) return i
        return next
      })
    }, playSpeed)
    return () => clearInterval(id)
  }, [isPlaying, steps.length])

  useEffect(() => {
    if (activeIndex < 0) return
    const el = document.getElementById(`step-${activeIndex}`)
    if (el) el.scrollIntoView({ behavior: "smooth", block: "center" })
  }, [activeIndex])

  /* ---------- controls ---------- */
  const canPrev = activeIndex > 0
  const canNext = activeIndex < steps.length - 1 && steps.length > 0

  const handlePrev = () => setActiveIndex((i) => (i > 0 ? i - 1 : i))
  const handleNext = () => setActiveIndex((i) => (i < steps.length - 1 ? i + 1 : i))
  const handleRestart = () => setActiveIndex(steps.length > 0 ? 0 : -1)
  const togglePlay = () => setIsPlaying((p) => !p)

  const total = steps.length
  const played = activeIndex + 1
  const progressPct = total > 0 && played > 0 ? Math.min(100, Math.round((played / total) * 100)) : 0

  /* ---------- GUI View ---------- */
  const GUIView = (
    <div className="space-y-6">
      {/* FCM status */}
      <div className="card p-4 flex items-center justify-between gap-4">
        <div className="text-sm">
          <div className="font-medium mb-1">Push Delivery</div>
          <div className="text-gray-400">
            {fcmSupported ? "Web Push is supported" : "Web Push not supported in this browser"}
            {" • "}
            Permission: <strong>{notifPermission}</strong>
            {fcmToken ? (
              <>
                {" • "}
                Token: <code className="text-xs">{fcmToken.slice(0, 12)}…{fcmToken.slice(-8)}</code>
              </>
            ) : null}
          </div>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-ghost" onClick={enableNotifications} disabled={!fcmSupported}>
            {fcmToken ? "Refresh Token" : "Enable Notifications"}
          </button>
        </div>
      </div>

      {classification && (
        <div className="card p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm uppercase tracking-wider text-gray-400">Classification</div>
            <Pill tone={classification.kind === "unknown" ? "warn" : "ok"}>{classification.kind}</Pill>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <K>Severity</K>
              <div className="font-medium">{classification.severity}</div>
            </div>
            <div>
              <K>Uncertainty</K>
              <div className="font-medium">{classification.uncertainty}</div>
            </div>
          </div>
        </div>
      )}

      {steps.length > 0 && (
        <section className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="text-sm uppercase tracking-wider text-gray-400">Chain of Thought</div>
            <div className="flex items-center gap-2">
              <button className="btn btn-ghost" onClick={handlePrev} disabled={!canPrev} title="Previous step">
                <span className="icon">⟸</span>Prev
              </button>
              <button
                className="btn btn-primary"
                onClick={togglePlay}
                disabled={total === 0}
                title={isPlaying ? "Pause" : "Play"}
              >
                <span className="icon">{isPlaying ? "⏸" : "▶"}</span>
                {isPlaying ? "Pause" : "Play"}
              </button>
              <button className="btn btn-ghost" onClick={handleNext} disabled={!canNext} title="Next step">
                Next
                <span className="icon" style={{ marginLeft: 6 }}>
                  ⟹
                </span>
              </button>
              <button className="btn btn-ghost" onClick={handleRestart} disabled={total === 0} title="Restart playback">
                ↺ Restart
              </button>
              <label className="pill cursor-pointer" title="Follow latest step while streaming">
                <input
                  type="checkbox"
                  checked={followLive}
                  onChange={(e) => setFollowLive(e.target.checked)}
                  style={{ accentColor: "var(--grab-green)", marginRight: 6 }}
                />
                Follow Live
              </label>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-4">
            <div className="timeline flex-1">
              <div className="timeline__bar" style={{ width: `${progressPct}%` }} />
            </div>
            <div className="text-xs text-gray-400 tabular-nums">
              {played}/{total}
            </div>
          </div>

          <div className="relative">
            {steps.map((s, i) => (
              <StepItem key={s.idx ?? i} step={s} index={i} active={i === activeIndex} complete={i <= activeIndex} />
            ))}
          </div>
        </section>
      )}

      {summary && (
        <div className="card p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm uppercase tracking-wider text-gray-400">Summary</div>
            <Pill tone={summary.outcome === "resolved" ? "ok" : summary.outcome === "escalated" ? "warn" : "neutral"}>
              {summary.outcome}
            </Pill>
          </div>
          <div className="text-gray-200 mb-3">{summary.summary || "—"}</div>
          {summary.metrics && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
              <div className="rounded-xl bg-black/30 border border-[var(--grab-edge)] p-3">
                <K>Steps</K>
                <div className="font-semibold">{summary.metrics.steps}</div>
              </div>
              <div className="rounded-xl bg-black/30 border border-[var(--grab-edge)] p-3">
                <K>Duration</K>
                <div className="font-semibold">{summary.metrics.totalSeconds}s</div>
              </div>
              <div className="rounded-xl bg-black/30 border border-[var(--grab-edge)] p-3">
                <K>Scenario</K>
                <div className="font-semibold truncate" title={scenarioText}>
                  {scenarioText}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )

  /* ---------- CLI View ---------- */
  const CLIView = (
    <div className="card p-4">
      <div className="text-xs text-gray-400 mb-2">Raw SSE (read-only)</div>
      <pre className="cli" aria-readonly="true" aria-live="polite">
        {rawLines.map((l, i) => `[${(i + 1).toString().padStart(3, "0")}] ${l}`).join("\n")}
      </pre>
    </div>
  )

  return (
    <div className="space-y-4">
      <div className="flex gap-3 items-center flex-wrap">
        <button className="btn btn-primary" onClick={start} disabled={!scenarioText || status === "streaming"}>
          {status === "streaming" ? "Streaming…" : "Run Scenario"}
        </button>
        <button className="btn btn-ghost" onClick={stop} disabled={status !== "streaming"}>
          Stop
        </button>
        <div className="text-sm text-gray-400 self-center select-all hidden md:block">
          API: <code className="font-mono">{previewUrl || "—"}</code>
        </div>
        <div className="flex-1" />
        <ViewToggle mode={mode} setMode={setMode} />
      </div>

      {error && <div className="card border-rose-800 bg-rose-950/40 p-3">{error}</div>}

      {mode === "gui" ? GUIView : CLIView}
    </div>
  )
}
