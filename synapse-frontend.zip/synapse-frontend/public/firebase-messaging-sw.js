/* eslint-disable no-undef */
importScripts("https://www.gstatic.com/firebasejs/10.12.3/firebase-app-compat.js")
importScripts("https://www.gstatic.com/firebasejs/10.12.3/firebase-messaging-compat.js")

firebase.initializeApp({
  apiKey: "AIzaSyDOlod9mcpsqWJdalalPka7CbAhOvHN6Jo",
  authDomain: "synapse-54cfb.firebaseapp.com",
  projectId: "synapse-54cfb",
  storageBucket: "synapse-54cfb.firebasestorage.app",
  messagingSenderId: "844442984824",
  appId: "1:844442984824:web:252a836b759d196a65e88d",
  measurementId: "G-D3NW1C1JXZ",
})

const messaging = firebase.messaging()
messaging.onBackgroundMessage((payload) => {
  const { title, body } = payload.notification || {}
  self.registration.showNotification(title || "Synapse", { body: body || "" })
})
